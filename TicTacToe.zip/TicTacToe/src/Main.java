
public class Main {

	public static void main(String args[]) {
		TicTacToe tictactoe = new TicTacToe();
	}
}
